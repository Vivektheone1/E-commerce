const port = 4000;
const express = require("express");
const mongoose = require("mongoose");
const app = express();
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const cors = require("cors");
const { error } = require("console");
const { type } = require("os");


app.use(express.json());

app.use(cors());
//DataBase connectivity with monogodb
mongoose.connect(
  "mongodb+srv://anmolgargag18:anmol1809@cluster1.5kyod.mongodb.net/"
);

// Api created
app.get("/", (req, res) => {
  res.send("server is running");
});

const fetchuser = (req, res, next) => {
  const token = req.header('auth-token');

  if (!token) {
    return res.status(401).send({ errors: 'Please authenticate the user' });
  }

  try {
    const data = jwt.verify(token, 'secret_ecom'); // Ensure this secret matches your JWT generation secret
    req.user = data.user; // Assuming the JWT contains user data in 'data.user'
    next(); // Pass to the next middleware/route handler
  } catch (error) {
    return res.status(401).send({ errors: 'Invalid token, please authenticate the user' });
  }
};
//addtocart
app.post('/addtocart',fetchuser,async (req, res) => {
  console.log(req.body,req.user.id);
  let userData = await Users.findOne({_id:req.user.id});
  userData.cartData[req.body.id] +=1;
  await Users.findOneAndUpdate({_id:req.user.id},{cartData:userData.cartData});
res.send("Added");
});
//removecart
app.post('/removefromcart',fetchuser,async(req,res)=>{
  console.log("removed",req.body.id);  
  let userData = await Users.findOne({_id:req.user.id});
  if(userData.cartData[req.body.id]>0)
  userData.cartData[req.body.id] -=1;
  await Users.findOneAndUpdate({_id:req.user.id},{cartData:userData.cartData});
res.send("Removed");
})
//getcart
app.post('/getcart',fetchuser,async(req,res)=>{
  console.log("getCart");
  let userData = await Users.findOne({_id:req.user.id});
  res.json(userData.cartData);
})
//image storage engine
const storage = multer.diskStorage({
  destination:"./upload/images",
  filename: (req, file, cb) => {
    cb(null,`${file.fieldname}_${path.basename(file.originalname,path.extname(file.originalname))}_${Date.now()}_${path.extname(file.originalname)}`);
  }  
});

const upload = multer({ storage: storage });

//creating upload endpoint for images
app.use("/images",express.static('upload/images'))
app.post("/upload",upload.single('product'),(req,res)=>{
    res.json({
        success:true,
        image_url:`http://localhost:${port}/images/${req.file.filename}`

    })
    
})
//schema for crrating products
const Product=mongoose.model("Product",{
    id:{
        type:Number,
        required:true,
    },
    name:{
        type:String,
        required:true,
    },
    image:{
        type:String,
        required:true,
    },
    category:{
        type:String,
        required:true,
    },
    old_price:{
        type:Number,
        required:true,
    },
    new_price:{
        type:Number,
        required:true,
    },
    date:
    {
        type:Date,
        default:Date.now(),
    },
    avilable:{
        type:Boolean,
        default:true,
    },

})

const Users = mongoose.model('Users',{
  name:{
    type:String,
    required:true,
  },
  email:{
    type:String,
    required:true,
    unique:true,
  },
  password:{
    type:String,
    required:true
  },
  cartData:{
    type:Object
  },
  date:{
    type:Date,
    default:Date.now
  }

})
//adduser
app.post("/signup",async(req,res)=>{
  let check =await Users.findOne({email:req.body.email});
  if(check)
  {
    return res.status(404).json({
      success:false,
      errors:"existing user found"
    })
  }
  const cart={};
    for(let index=0; index<36;index++)
    {
      cart[index]=0
    }
  const user =new Users({
   name:req.body.name,
   email:req.body.email,
   password:req.body.password,
   cartData:cart
  });
  await user.save();
  
  const data ={
    user:{
      id:user.id
    }
  }
  console.log("success",user);
  const token = jwt.sign(data,'secrect_eocom');
  res.json({success:true,token})
})
//Login user
app.post('/login',async(req,res)=>{
  let user = await Users.findOne({email:req.body.email});
  if(user)
  {
    const passcompare=req.body.password === user.password;
    if(passcompare)
    {
      const data ={
        user:{
          id:user.id
        }
      }
      const token=jwt.sign(data,'secret_ecom');
      res.json({
        success:true,
        token
      });
    }
    else{
      res.json({
        success:false,
        errors:"Password is incorect"
      });
    }

  }
  else{
    res.json({
      success:false,
      errors:"Not a valid user"
    })
  }
})
//addtoproduct
app.post("/addproduct",async(req,res)=>{
   let products = await Product.find({});
   let id=0;
   let n=products.length
      if(products.length>0)
      {
        id=products[n-1].id    ;
        id=id+1;
      }
      else{
       id=1
      }
   const product=new Product({
    id:id,
    name:req.body.name,
    category:req.body.category,
    new_price:req.body.new_price,
    old_price:req.body.old_price,
    image:req.body.image,

   });

   await product.save();
   res.json({
    success:"true",
   
   })
})

//Remove product
 app.post("/removeproduct",async(req,res)=>
{
    await Product.findOneAndDelete({id:req.body.id})
    console.log("successfully deleted");
    res.json({
        success:"true", 
    })
})
//gettimng all_products
app.get("/allproduct",async(req,res)=>
{
    let products= await Product.find({});
    res.send(products);  
    })


// Server created
app.listen(port, (error) => {
  if (!error) {
    console.log("Server running" + port);
  } else {
    console.log("error" + error);
  }
});
