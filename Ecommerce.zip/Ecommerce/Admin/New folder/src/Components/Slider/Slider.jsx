import React from 'react'
import './Slider.css'
import {Link} from 'react-router-dom'
import add_product_icon from '../../assets/Product_Cart.svg'
import product_list_icon from '../../assets/Product_list_icon.svg'
import cross_icon from '../../assets/Product_Cart.svg'
const Slider = () => {
  return (
    <div className='slidebar'>
       <Link to={'/Addtoproduct'} style={{textDecoration:"none"}}>
       <div className='sidebar-item'>
        <img src={add_product_icon} alt="" />
        <p>Add Product</p>
       </div>
       </Link>

       <Link to={'/Listproduct'} style={{textDecoration:"none"}}>
       <div className='sidebar-item'>
        <img src={product_list_icon} alt="" />
        <p>Product List</p>
       </div>
       </Link>

       <Link to={'/removeproduct'} style={{textDecoration:"none"}}>
       <div className='sidebar-item'>
        <img src={add_product_icon} alt="" />
        <p>Remove Product</p>
       </div>
       </Link>


    </div>
  )
}

export default Slider