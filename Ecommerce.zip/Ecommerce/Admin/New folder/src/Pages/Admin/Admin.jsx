import React from 'react'
import Slider from '../../Components/Slider/Slider'
import { Routes } from 'react-router-dom'
import { Route } from 'react-router-dom'
import Addproduct from '../../Components/Addproduct/Addproduct';
import './Admin.css';
import ListProduct from '../../Components/ListProduct/ListProduct';

const Admin = () => {
  return (
    <>
    <div className='admin'>
      
    <Slider/>
   <Routes>
    <Route path='/Addtoproduct' element={<Addproduct/>}/>
    <Route path='/Listproduct' element={<ListProduct/>}/>
   </Routes>
     </div>
    </>
  )
}

export default Admin