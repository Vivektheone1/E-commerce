import React from 'react'
import { Cartitems } from '../Components/Cart/Cartitems'

export const Cart = () => {
  return (
    <div>
      <Cartitems/>
    </div>
  )
}
