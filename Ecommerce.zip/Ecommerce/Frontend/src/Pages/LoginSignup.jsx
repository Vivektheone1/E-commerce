import React, { useState } from "react";
import "../Pages/CSS/loginSignup.css";
export const LoginSignup = () => {
  const [state, setState] = useState("Login");
  const [sign, setSign] = useState({
    name: "",
    email: "",
    password: "",
  });
  const signhandler = (e) => {
    setSign({ ...sign, [e.target.name]: e.target.value });
  };
  const userlogin = async () => {
    let response_data ;
    await fetch("http://localhost:4000/login", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(sign),
    })
      .then((resp) => resp.json())
      .then((data) => {
       response_data = data; 
       
        if(response_data.success)
        {
           alert("successfully signed");
           localStorage.setItem('auth-token',response_data.token);
           window.location.replace("/");
        }
        else{
          alert(response_data.errors);
        }
      });
  };
  const createuser = async () => {
   let response_data ;
    await fetch("http://localhost:4000/signup", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(sign),
    })
      .then((resp) => resp.json())
      .then((data) => {
       response_data = data; 
       
        if(response_data.success)
        {
           alert("successfully signed");
           localStorage.setItem('auth-token',response_data.token);
           window.location.replace("/");
        }
        else{
          alert(response_data.errors);
        }
      });
  };
  return (
    <div className="logindiv">
      <div className="login-container">
        <h1>{state}</h1>
        <div className="login-fields">
          {state === "Sign Up" ? (
            <input
              type="text"
              name="name"
              onChange={signhandler}
              value={sign.name}
              placeholder="Your Name"
            />
          ) : (
            ""
          )}
          <input
            type="email"
            name="email"
            onChange={signhandler}
            value={sign.email}
            placeholder="Email address"
          />
          <input
            type="password"
            name="password"
            onChange={signhandler}
            value={sign.password}
            placeholder="Password"
          />
        </div>

        {state === "Sign Up" ? (
          <p>Alredy have an accout?{" "}<a href onClick={() => {setState("Login");}} > Login </a> </p>) : ( <p>
            Create an account{" "}
            <a href onClick={() => { setState("Sign Up");}}>
              Click Here </a></p>)}
        <div className="termsconditions">
          <input type="checkbox" name="" id="" />
          <p>By continuing,I agree to the terms and conditions</p>
        </div>
        <button onClick={state === "Sign Up" ? createuser : userlogin}>
          Continue
        </button>
      </div>
    </div>
  );
};
