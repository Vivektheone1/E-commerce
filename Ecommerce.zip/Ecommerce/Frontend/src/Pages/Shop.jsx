import React from 'react'
import { Hero } from '../Components/Hero/Hero'
import { Popular } from '../Popular/Popular'
import { Offers } from '../Offers/Offers'
import { Newcollections } from '../Components/Newcollections/Newcollections'
import { News } from '../Components/News/News'


export const Shop = () => {
  return (
    <div>
        <Hero/>
        <Popular/>
        <Offers/>
        <Newcollections/>   
        <News/> 
        
    </div>
  )
}
