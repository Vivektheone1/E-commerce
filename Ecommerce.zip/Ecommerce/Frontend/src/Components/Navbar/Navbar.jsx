
import '../Navbar/Navbar.css'
import logo from '../Assets/logo.png'
import cart_icon from '../Assets/cart_icon.png'
import { useContext, useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { ShopContext } from '../../Context/ShopContext'

export const Navbar = (props) => {
const [menu,setMenu]= useState("");
const {gettotalamount}=useContext(ShopContext);
const {count}=gettotalamount();
  return (
    <div className='navbar'>
     <Link style={{textDecoration: 'none'}} onClick={()=>{setMenu("shop")}} to='/'><div className="nav-logo">
      <img src={logo}  alt="" />
      <p>SHOPPER</p>
     </div></Link>
     <ul className='nav-menu'>
        <li onClick={()=>{setMenu("shop")}}><Link style={{textDecoration: 'none'}} to='/'>Shop</Link>{menu==="shop"?<h/>:<></>}</li>
        <li onClick={()=>{setMenu("mens")}}><Link style={{textDecoration: 'none'}} to='/Men'>Men</Link>{menu==="mens"?<h/>:<></>}</li>
        <li onClick={()=>{setMenu("womens")}}><Link style={{textDecoration: 'none'}} to='/Women'>Women</Link>{menu==="womens"?<h/>:<></>}</li>
        <li onClick={()=>{setMenu("kids")}}><Link style={{textDecoration: 'none'}} to='/kids'>Kids</Link> {menu==="kids"?<h/>:<></>}</li>
     </ul>
        <div className="div nav-login-cart">
            {localStorage.getItem('auth-token')? <Link onClick={()=>{setMenu("")}} to='/login'><button onClick={()=>{localStorage.removeItem('auth-token');window.location.replace('/login')}}>Logout</button></Link>
            :  <Link onClick={()=>{setMenu("")}} to='/login'><button>Login</button></Link>}
           
            <Link onClick={()=>{setMenu("cart")}} to='/cart'> <img src={cart_icon} alt="" /></Link>
            <div className="nav-cart-count">
                {count}
            </div>
        </div>
    </div>
  )
}
