import React, { useContext } from 'react'
import './Newcollections.css'
import { Item } from '../Item/Item.jsx'
import { ShopContext } from '../../Context/ShopContext.jsx'
 
export const Newcollections = () => {

  const {all_product} = useContext(ShopContext);

  // Get the last 8 elements from the all_products array
  const new_collections = all_product.slice(-8);

  return (
    <div className='Newcollections'>
<h1> New Collections</h1>
<hr/>
<div className="Newcollection_item">

 {new_collections.map((item,i)=>{

    return <Item  key={i} id={item.id} name={item.name} image={item.image} new_price={item.new_price} old_price={item.old_price}/>
 }

)}


</div>

    </div>
  )
}
