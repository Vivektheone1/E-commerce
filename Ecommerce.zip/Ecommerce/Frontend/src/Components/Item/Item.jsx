  import React from 'react'
  import '../Item/Item.css'
  import  rupee_indian from '../Item/rupee-indian.png'
  import { Link } from 'react-router-dom'
  export const Item = (props)   => {
    return (
      <div className='item'>
          <Link to={`/product/${props.id}`}><img onClick={() => window.scrollTo(0, 0)} src={props.image} alt=""  /></Link>
          <p>{props.name}</p>
          <div className="item-prices">
              <div className="item-new-price">
                <img src={rupee_indian} alt="" /> {props.new_price}
              </div>
              <div className="item-old-price">
              <img src={rupee_indian} alt="" />{props.old_price}
              </div>
          </div>
      </div>
    )
  }
