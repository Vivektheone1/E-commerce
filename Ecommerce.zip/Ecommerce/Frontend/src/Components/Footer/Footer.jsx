import React from 'react';
import './Footer.css'
import logo from '../Assets/logo.png'
import { Link } from 'react-router-dom';
export const Footer = () => {
  return (
    <div className='footer'>
        <div className='footer-logo'>
        <img src={logo} alt="logo" />
        <p>Shopper</p>
        </div>
      
          <ul type="none" className='footer-links'>
            <Link to='/' style={{textDecoration: 'none'}}><li>Home</li></Link>
            <li>Shop</li>
            <li>Contact</li>
            <li>About</li>
          </ul>

        <div className='social-icon'>
        <i className="fa-brands fa-whatsapp"></i>
        <i className="fa-brands fa-facebook"></i>
        <i className="fa-brands fa-instagram"></i>
        <i className="fa-brands fa-twitter"></i>
        </div>
        <div className='Copyright'>
          <hr/>
            <p>Copyright 2024 Anmol Garg</p>
        </div>

    
    </div>
  )
}
