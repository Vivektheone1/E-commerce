import React, { useContext } from "react";
import "./Productdisplay.css";
import star_icon from "../Assets/star_icon.png";
import star_dull_icon from "../Assets/star_dull_icon.png";
import { ShopContext } from "../../Context/ShopContext";

export const Productdisplay = (props) => {
  const { product } = props;
  const {addtocart} = useContext(ShopContext);
  
  return (
    <>
    <div className="productdisplay">
      <div className="productdisplay-left">
        <div className="productdisplay-img-list">
          <img src={product.image} alt="" />
          <img src={product.image} alt="" />
          <img src={product.image} alt="" />
          <img src={product.image} alt="" />
        </div>
        <div className="productdisplay-img">
          <img className="product-display-main" src={product.image} alt="" />
        </div>
      </div>
      <div className="productdisplay-right">
        <h1>{product.name}</h1>
        <div className="productdisplay-right-star">
          <img src={star_icon} alt="" />
          <img src={star_icon} alt="" />
          <img src={star_icon} alt="" />
          <img src={star_icon} alt="" />
          <img src={star_dull_icon} alt="" />
          <p>(122)</p>
        </div>
        <div className="productdisplay-right-prices">
          <div className="productdisplay-right-price-old">{product.old_price}</div>
          <div className="productdisplay-right-price-new">{product.new_price}</div>
        </div>
        <div className="productdisplay-right-description">
         Lorem, ipsum dolor sit amet consectetur adipisicing elit. Enim totam ut accusamus culpa unde, earum excepturi, ipsam nesciunt illo id non commodi quasi et, porro sapiente cum vero sint neque?
         Lorem ipsum, dolor sit amet consectetur adipisicing elit. Volupt
        </div>
        <div className="productdisplay-right-size">
          <h1>Select size</h1>
          <div className="productdisplay-right-sizes">
            <div>S</div>
            <div>M</div>
            <div>L</div>
            <div>XL</div>
            <div>XXL</div>
          </div>
        </div>
        <button onClick={()=>{addtocart(product.id)}}>ADD to Cart</button>
       
      </div>
    </div>

    <div className="discriptionbox">
      <div className="discriptionbox-navigator">
        <div className="discriptionbox-nav-box">Description</div>
        <div className="discriptionbox-nav-box fade">Reviews</div>
      </div>
      <div className="descriptionbox-description">
        <p>
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nisi quaerat magni unde cumque deserunt voluptas optio ex, sunt velit maxime, voluptate sed eius adipisci molestiae nemo impedit voluptatum ut officia?
        </p>
      </div>
    </div>
    </>
  );
};
