import React from 'react'
import '../Popular/Popular.css'
import { Item } from '../Components/Item/Item';
import { useContext } from 'react';
import { ShopContext } from '../Context/ShopContext.jsx';
export const Popular = () => {
  const {all_product} = useContext(ShopContext);
  const women_product = all_product.filter(product => product.category ==='women')
  const data_product = women_product.slice(-4);
  return (
    <div className='popular'>
        <h1>POPULAR IN WOMEN</h1>
         <hr/>
         <div className="popular-item">
            {data_product.map((item,i)=>{

                return <Item key={i} id={item.id} name={item.name} image={item.image} new_price={item.new_price} old_price={item.old_price}/>
            })}

         </div>

    </div>
  )
}
