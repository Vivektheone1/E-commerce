import React, { useEffect, useState } from "react";
import { createContext } from "react";
import { json } from "react-router-dom";

export const ShopContext = createContext(null);


const ShopContextProvider = (props) => {
  const[all_product,setAll_product] = useState([]);
 
  useEffect(() => {
    fetch('http://localhost:4000/allproduct')
      .then((res) => res.json())
      .then((data) => setAll_product(data));
  
    if (localStorage.getItem('auth-token')) {
      fetch('http://localhost:4000/getcart', {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'auth-token': `${localStorage.getItem('auth-token')}`,
          'Content-Type': 'application/json',
        },
        body: null,
      })
        .then((res) => res.json())
        .then((data) => setCartItems(data))
        .catch((error) => console.error('Error fetching cart:', error));
    }
  }, []);

  
  const getdefaultcart = () => {
    let cart = {};
    for (let index = 0; index < 36; index++) {
      cart[index] = 0;
    }
    
    return cart;
  };

  const [cartItems, setCartItems] = useState(getdefaultcart());

  const addtocart = (itemID) => {
    setCartItems((prev) => ({ ...prev, [itemID]: prev[itemID] + 1 }));
    
    if (localStorage.getItem('auth-token')) {
      fetch('http://localhost:4000/addtocart', {
        method: 'POST',
        headers: {  // Corrected from 'header' to 'headers'
          Accept: 'application/json',
          'auth-token': `${localStorage.getItem('auth-token')}`,
          'Content-Type': 'application/json',  // Ensure this is 'Content-Type'
        },
        body: JSON.stringify({ id: itemID }),
      })
        .then((res) => res.json())
        .then((data) => console.log(data))
        .catch((error) => console.error('Error:', error));
    }
  };
  
  const removetocart = (itemID) => {
    setCartItems((prev) => ({ ...prev,[itemID]:prev[itemID]- 1 }));
    if (localStorage.getItem('auth-token')) {
      fetch('http://localhost:4000/removefromcart', {
        method: 'POST',
        headers: {  // Corrected from 'header' to 'headers'
          Accept: 'application/json',
          'auth-token': `${localStorage.getItem('auth-token')}`,
          'Content-Type': 'application/json',  // Ensure this is 'Content-Type'
        },
        body: JSON.stringify({ id: itemID }),
      })
        .then((res) => res.json())
        .then((data) => console.log(data))
        .catch((error) => console.error('Error:', error));
    }
  };
 


  const gettotalamount=()=>{
   let totalamount=0;
   let count=0;

   for (const i in cartItems)
   {
      if(cartItems[i]>0)
      {
        let iteminfo = all_product.find((e) => e.id === Number(i));
        totalamount+=iteminfo.new_price*cartItems[i];
        count += cartItems[i];

      }
   }
   return {count,totalamount};
  };


  const contextvalue = {all_product,cartItems,addtocart,removetocart,gettotalamount};
  return (
    <ShopContext.Provider value={contextvalue}>
      {props.children}
    </ShopContext.Provider>
  );
};

export default ShopContextProvider;
